#include "Contact.h"
bool Contact::numcheck(std::string num) // to check to the length of number
{
	if (num.length() != 11)
	{
		return false;
	}
	std::string str = "1234567890";
	bool flag = false;
	for (int i = 0; num[i] != '\0'; i++)
	{
		flag = false;
		for (int j = 0; j < 10; j++)
		{
			if (num[i] == str[j])
			{
				flag = true;
				j = 10;
			}
		}
		if (!flag)
		{
			return flag;
		}
	}
	return flag;
}
Contact::Contact(int id, std::string first_name, std::string last_name, std::string mobile_number, std::string email_address, Address *address)
{
	this->id = id;
	this->first_name = first_name;
	this->last_name = last_name;
	this->mobile_number = mobile_number;
	this->email_address = email_address;
	this->address = new Address(*address);
}
// setters
void Contact::setId(int id)
{
	this->id = id;
}
int Contact::getId()
{
	return id;
}
void Contact::setFirstName(std::string first_name)
{
	while (first_name.length() == 0)
	{
		std::cout << "Invalid Name .Please try again : ";
		getline(std::cin, first_name);
	}
	this->first_name = first_name;
}
void Contact::setLastName(std::string last_name)
{
	while (last_name.length() == 0)
	{
		std::cout << "Invalid Name .Please try again : ";
		getline(std::cin, last_name);
	}
	this->last_name = last_name;
}
void Contact::setMobileNumber(std::string mobile_number)
{
	while (!numcheck(mobile_number))
	{
		std::cout << "Invlaid Number .Try Again : ";
		getline(std::cin, mobile_number);
	}
	this->mobile_number = mobile_number;
}
void Contact::setEmail(std::string email_address)
{
	this->email_address = email_address;
}
void Contact::setAddress(Address &address)
{
	this->address = new Address(address);
}
// getters
std::string Contact::getFirstName()
{
	return this->first_name;
}
std::string Contact::getLastName()
{
	return this->last_name;
}
std::string Contact::getMobileNumber()
{
	return this->mobile_number;
}
std::string Contact::getEmail()
{
	return this->email_address;
}
Address *Contact::getAdress()
{
	return (this->address);
}
bool Contact::equals(Contact contact)
{
	if (this->first_name == contact.first_name && this->last_name == contact.last_name && this->mobile_number == contact.mobile_number && this->email_address == contact.email_address && address->equals(*(contact.address)))
	{
		return true;
	}
	return false;
}
Contact::Contact(const Contact &obj)
{
	this->id = obj.id;
	this->first_name = obj.first_name;
	this->last_name = obj.last_name;
	this->mobile_number = obj.mobile_number;
	this->email_address = obj.email_address;
	Address obj1 = obj.address->copy_address();
	this->address = new Address(obj1);
}
Contact::Contact(Contact &obj)
{
	this->id = obj.id;
	this->first_name = obj.first_name;
	this->last_name = obj.last_name;
	this->mobile_number = obj.mobile_number;
	this->email_address = obj.email_address;
	Address obj1 = obj.address->copy_address();
	this->address = new Address(obj1);
}
Contact *Contact::copy_contact() const
{
	Contact *ptr = new Contact(*this);
	return ptr;
}
void Contact::operator=(Contact obj)
{
	this->id = obj.id;
	this->first_name = obj.first_name;
	this->last_name = obj.last_name;
	this->mobile_number = obj.mobile_number;
	this->email_address = obj.email_address;
	Address obj1 = obj.address->copy_address();
	this->address = new Address(obj1);
}
void Contact::PrintContact()
{
	std::cout << "ID            : " << id << std::endl;
	std::cout << "Name          : " << first_name << " " << last_name << std::endl;
	std::cout << "Mobile Number : " << mobile_number << std::endl;
	std::cout << "Email         : " << email_address << std::endl;
	if (address)
	{
		address->print_address();
	}
}

Contact::~Contact()
{
	if (address)
	{
		/*delete address;
		address = nullptr;*/
	}
	idMaker--;
}
int Contact::idMaker = -1;