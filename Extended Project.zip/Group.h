#pragma once
#include <string>
#include "List.h"
#include "Contact.h"
class Group
{
private:
	static int idMaker;
	int id = 0;
	std::string name;
	List<int> contact_id;
	List<Contact> contacts;

public:
	Group()
	{
	}
	void setContactId(int contact_id)
	{
		this->contact_id.push(contact_id);
	}
	void setId(int id)
	{
		this->id = id;
	}
	void setContact(Contact obj)
	{
		contacts.push(obj);
	}
	void deleteContact(int contact_id)
	{
		for (int i = 0; i < this->contact_id.size(); i++)
		{
			if (id == contact_id)
			{
				this->contact_id.deleteIndex(i);
			}
		}
	}
	int getSize()
	{
		return contact_id.size();
	}
	int getId()
	{
		return id;
	}
	void setName(std::string name)
	{
		this->name = name;
	}
	std::string getname()
	{
		return name;
	}
	~Group() {}
};