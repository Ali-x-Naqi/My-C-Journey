#pragma once
#include <iostream>
template <typename T>
class List
{
private:
    int Size;
    int capacity;
    T *array = nullptr;
    void reSize();

public:
    List();
    List(int Size);
    void push(T var);
    T pop();
    int size();
    int search(T var);
    int begin();
    int end();
    void deleteIndex(int);
    int Capacity();
    T operator[](int index);
    ~List()
    {
        /*if(array!=nullptr)
        delete array;
        array = nullptr;*/
    }
};
// #include "List.h"
template <typename T>
List<T>::List()
{
    capacity = 1;
    Size = 0;
    array = new T[capacity];
}
template <typename T>
List<T>::List(int Size)
{
    if (Size > 0)
    {
        capacity = Size;
        this->Size = Size;
        array = new T[capacity];
    }
    else if (Size == 0)
    {
        capacity = 1;
        this->Size = Size;
        array = new T[capacity];
    }
}
template <typename T>
void List<T>::push(T var)
{
    if (Size == capacity)
    {
        reSize();
    }
    array[Size] = var;
    Size++;
}
template <typename T>
T List<T>::operator[](int index)
{
    return array[index];
}
template <typename T>
T List<T>::pop()
{
    T temp = array[Size - 1];
    Size--;
    T *ptr = new T[capacity];
    for (int i = 0; i < Size; i++)
    {
        ptr[i] = array[i];
    }
    delete array;
    array = ptr;
    ptr = nullptr;
    return temp;
}
template <typename T>
int List<T>::size()
{
    return Size;
}
template <typename T>
int List<T>::search(T var)
{
    for (int i = 0; i < Size; i++)
    {
        if (array[i] == var)
        {
            return i;
        }
    }
    return -1;
}
template <typename T>
int List<T>::begin()
{
    return 0;
}
template <typename T>
int List<T>::end()
{
    return Size;
}
template <typename T>
void List<T>::reSize()
{
    capacity += 10;
    T *ptr = new T[capacity];
    for (int i = 0; i < Size; i++)
    {
        ptr[i] = array[i];
    }
    delete array;
    array = ptr;
    ptr = nullptr;
}
template <typename T>
int List<T>::Capacity()
{
    return capacity;
}
template <typename T>
void List<T>::deleteIndex(int index)
{
    if (index < Size && index >= 0)
    {
        int j = 0;
        Size--;
        T *ptr = new T[capacity];
        for (int i = 0; i < Size; i++)
        {
            if (j == index)
            {
                j++;
            }
            ptr[i] = array[j];
            j++;
        }
        delete array;
        array = ptr;
        ptr = nullptr;
    }
}
