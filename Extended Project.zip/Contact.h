#pragma once
#ifndef BASIC_LIB
#define BASIC_LIB
#include <iostream>
#include <string>
#endif // !BASIC_LIB
#include "Address.h"
class Contact
{
private:
	std::string first_name;
	std::string last_name;
	std::string mobile_number;
	std::string email_address;
	Address *address = nullptr;
	static int idMaker;
	int id;

public:
	// declaration of functions
	bool equals(Contact contact);
	Contact *copy_contact() const;
	bool numcheck(std::string num);
	Contact()
	{
		idMaker++;
		id = idMaker;
	}
	void setId(int id);
	int getId();
	Contact(int id, std::string first_name, std::string last_name, std::string mobile_number, std::string email_address, Address *address);
	Contact(const Contact &obj);
	Contact(Contact &obj);
	void setFirstName(std::string first_name);
	void setLastName(std::string last_name);
	void setMobileNumber(std::string mobile_number);
	void setEmail(std::string email_address);
	void setAddress(Address &address);
	std::string getFirstName();
	std::string getLastName();
	std::string getMobileNumber();
	std::string getEmail();
	Address *getAdress();
	void operator=(Contact obj);
	void PrintContact();
	void editConatact();
	~Contact();
};
