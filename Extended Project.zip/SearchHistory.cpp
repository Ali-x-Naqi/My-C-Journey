#include "SearchHistory.h"
void SearhHistory::setDateTime(std::string dateTime)
{
    this->dateTime = dateTime;
}
void SearhHistory::setSearchedString(std::string searchedString)
{
    this->SearchedString = searchedString;
}
std::string SearhHistory::getDateTime()
{
    return dateTime;
}
std::string SearhHistory::getSearchedString()
{
    return SearchedString;
}