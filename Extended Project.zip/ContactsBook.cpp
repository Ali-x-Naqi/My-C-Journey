#include "ContactsBook.h"
#include <fstream>
using namespace std;
void setContacts(Contact &obj1, Contact &obj2)
{
	obj1.setId(obj2.getId());
	obj1.setFirstName(obj2.getFirstName());
	obj1.setLastName(obj2.getLastName());
	obj1.setMobileNumber(obj2.getMobileNumber());
	obj1.setEmail(obj2.getEmail());
	Address address = *(obj2.getAdress());
	obj1.setAddress(address);
}
List<Contact> ContactsBook::searchByString(std::string str)
{
	List<Contact> Arr;
	for (int i = 0; i < size_of_contacts; i++)
	{
		std::string firstn = contacts_list[i].getFirstName();
		std::string lastn = contacts_list[i].getLastName();
		std::string mail = contacts_list[i].getEmail();
		std::string phone = contacts_list[i].getMobileNumber();
		std::string house = (contacts_list[i].getAdress())->getHouse();
		std::string street = (contacts_list[i].getAdress())->getStreet();
		std::string city = (contacts_list[i].getAdress())->getCity();
		std::string country = (contacts_list[i].getAdress())->getCountry();
		if (firstn.find(str) >= 0 && firstn.find(str) < firstn.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}

		else if (lastn.find(str) >= 0 && lastn.find(str) < lastn.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (mail.find(str) >= 0 && mail.find(str) < mail.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (phone.find(str) >= 0 && phone.find(str) < phone.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (house.find(str) >= 0 && house.find(str) < house.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (street.find(str) >= 0 && street.find(str) < street.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (city.find(str) >= 0 && city.find(str) < city.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}
		else if (country.find(str) >= 0 && country.find(str) < country.size())
		{
			contacts_list[i].PrintContact();
			Arr.push(contacts_list[i]);
		}

	}
	return Arr;
}
void ContactsBook::add_contact(const Contact &contact)
{
	if (full()) // if user wants to add more contacts compare to size of array then extend the size
	{
		resize_list();
	}
	Contact obj = Contact(contact);
	setContacts(contacts_list[contacts_count], obj);
	if (contacts_count != 0)
	{
		int id = contacts_list[contacts_count - 1].getId();
		id++;
		contacts_list[contacts_count].setId(id);
		cout << "Id : " << id << endl;
	}
	contacts_list[contacts_count].PrintContact();
	contacts_count++;
}
int ContactsBook::total_contacts()
{
	return contacts_count;
}
bool ContactsBook::full()
{
	if (size_of_contacts <= contacts_count)
	{
		return true;
	}
	{
		return false;
	}
}

void ContactsBook::resize_list() // to extend the size of contacts
{
	if (size_of_contacts != 0)
	{
		size_of_contacts *= 2;
		Contact *newPtr = new Contact[size_of_contacts];
		for (int i = 0; i < contacts_count; i++)
		{
			setContacts(newPtr[i], contacts_list[i]);
		}
		delete[] contacts_list;
		contacts_list = newPtr;
		newPtr = nullptr;
	}
	else
	{
		size_of_contacts = 1;
		contacts_list = new Contact[size_of_contacts];
	}
}
ContactsBook::ContactsBook(int size_of_list) // to make array of contacts
{
	contacts_list = new Contact[size_of_list];
	contacts_count = 0;
	size_of_contacts = size_of_list;
}
Contact *ContactsBook::copy() // this function will help us in sorting
{
	Contact *newPtr = new Contact[contacts_count];
	for (int i = 0; i < contacts_count; i++)
	{
		setContacts(newPtr[i], contacts_list[i]);
	}
	return newPtr;
}
void ContactsBook::print_contacts_sorted(std::string choice) // to print sorted contacts
{
	Contact *temp = copy();

	sort_contacts_list(temp, choice);
	std::cout << "\t\t\tContacts In Sorted Format : \n";
	for (int i = 0; i < contacts_count; i++)
	{
		temp[i].PrintContact();
		std::cout << ::endl;
	}
	if (contacts_count != 0)
	{
		delete[] temp;
	}
}
void ContactsBook::sort_contacts_list(Contact *contacts_list, std::string choice) // to sort contacts
{
	if (choice == "first_name") // sorting by first name
	{
		for (int i = 0; i < contacts_count; i++)
		{
			for (int j = 0; j < contacts_count; j++)
			{
				if (((contacts_list[i].getFirstName())[0]) < ((contacts_list[j].getFirstName())[0]))
				{
					Contact temp;
					setContacts(temp, contacts_list[i]);
					setContacts(contacts_list[i], contacts_list[j]);
					setContacts(contacts_list[j], temp);
				}
			}
		}
	}
	else
	{
		for (int i = 0; i < contacts_count; i++) // sorting by last name
		{
			for (int j = 0; j < contacts_count; j++)
			{
				if (((contacts_list[i].getLastName())[0]) < ((contacts_list[j].getLastName())[0]))
				{
					Contact temp;
					setContacts(temp, contacts_list[i]);
					setContacts(contacts_list[i], contacts_list[j]);
					setContacts(contacts_list[j], temp);
				}
			}
		}
	}
}
void ContactsBook::deleteContact(int index) // to delete Particular index
{
	Contact *newPtr = new Contact[contacts_count];
	int j = 0;
	for (int i = 0; i < contacts_count - 1; i++)
	{
		if (index == j)
		{
			j++;
		}
		setContacts(newPtr[i], contacts_list[j]);
		j++;
	}
	delete[] contacts_list;
	contacts_list = newPtr;
	newPtr = nullptr;
	contacts_count--;
}
void ContactsBook::print_contacts() // to print all contacts
{
	for (int i = 0; i < contacts_count; ++i)
	{
		std::cout << "\n\t\tContact " << i + 1 << ":\n\n";
		contacts_list[i].PrintContact();
	}
}
void ContactsBook::merge_duplicates() // will merge duplicates
{
	int count = 0;
	bool flag = false;
	int *arr = nullptr;
	for (int i = 0; i < contacts_count; i++)
	{
		flag = false;
		for (int j = i + 1; j < contacts_count; j++)
		{
			if (contacts_list[i].equals(contacts_list[j]) && j != i)
			{
				deleteContact(j);
				flag = true;
				j--;
			}
		}
		if (flag)
		{
			count++;
			if (count == 1)
			{
				arr = new int[count];
				arr[0] = i;
			}
			else
			{
				int *newptr = new int[count];
				for (int k = 0; k < count - 1; k++)
				{
					newptr[k] = arr[k];
				}
				newptr[count - 1] = i;
				delete[] arr;
				arr = newptr;
				newptr = nullptr;
			}
		}
	}

	for (int i = 0; i < count; i++)
	{
		contacts_list[arr[i]].PrintContact();
	}

	std::cout << "Total Merged Contacts : " << count << std::endl;
}

void ContactsBook::load_from_file(std::string file_name) // file handling to load contacts
{
	std::ifstream handler(file_name);
	if (!handler)
	{
		std::cout << "Error: Unable to open file: " << file_name << std::endl;
	}
	else
	{
		if (size_of_contacts != 0 && contacts_list != nullptr)
		{
			delete[] contacts_list;
		}
		handler >> contacts_count;
		size_of_contacts = contacts_count;
		contacts_list = new Contact[size_of_contacts];
		handler.ignore();
		for (contacts_count = 0; contacts_count < size_of_contacts;)
		{
			std::string first_name, last_name, mobile_number, email_address;
			std::string house, street, city, country;
			std::getline(handler, first_name);
			std::getline(handler, last_name);
			std::getline(handler, mobile_number);
			std::getline(handler, email_address);
			std::getline(handler, house);
			std::getline(handler, street);
			std::getline(handler, city);
			std::getline(handler, country);
			Address address(house, street, city, country);
			Contact contact(0, first_name, last_name, mobile_number, email_address, &address);
			add_contact(contact);
		}
		handler.close();
	}
}

void ContactsBook::save_to_file(std::string file_name) // file handling to store contacts
{
	std::ofstream handler(file_name);
	if (!handler)
	{
		std::cout << "Error: Unable to create file: " << file_name << std::endl;
	}
	else
	{
		handler << contacts_count << std::endl;

		for (int i = 0; i < contacts_count; ++i)
		{
			handler << contacts_list[i].getFirstName() << std::endl;
			handler << contacts_list[i].getLastName() << std::endl;
			handler << contacts_list[i].getMobileNumber() << std::endl;
			handler << contacts_list[i].getEmail() << std::endl;
			handler << contacts_list[i].getAdress()->getHouse() << std::endl;
			handler << contacts_list[i].getAdress()->getStreet() << std::endl;
			handler << contacts_list[i].getAdress()->getCity() << std::endl;
			handler << contacts_list[i].getAdress()->getCountry() << std::endl;
		}
		handler.close();
	}
}
ContactsBook::~ContactsBook()
{
	if (contacts_list != nullptr && size_of_contacts != 0)
	{
		/*delete[] contacts_list;
		contacts_list = nullptr;*/
	}
}