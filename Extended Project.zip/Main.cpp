#include <iostream>
#include <limits>
#include <string>
#include <conio.h>
#include "List.h"
#include "Group.h"
#include "Address.h"
#include "Contact.h"
#include "ContactsBook.h"
#include "SearchHistory.h"
#include "HistoryObjects.h"
bool checkInput(std::string input)
{
    if (input.size() == 0)
    {
        return false;
    }
    bool flag = false;
    std::string str = "0123456789";
    for (int i = 0; i < input.size(); i++)
    {
        flag = false;
        for (int j = 0; j < 10; j++)
        {
            if (str[j] == input[i])
            {
                flag = true;
            }
        }
        if (!flag)
        {
            return flag;
        }
    }
    return flag;
}
std::istream &operator>>(std::istream &in, ContactsBook &contactsBook) // >> insertion operator overloading
{
    std::string fileName;
    std::string first_name, last_name, mobile_number, email_address;
    std::string house, street, city, country;
    std::cin.ignore();
    std::cout << "Enter First Name: ";
    std::getline(std::cin, first_name);
    std::cout << "Enter Last Name: ";
    std::getline(std::cin, last_name);
    std::cout << "Enter Mobile Number: ";
    std::getline(std::cin, mobile_number);
    std::cout << "Enter Email Address: ";
    std::getline(std::cin, email_address);
    std::cout << "Enter House: ";
    std::getline(std::cin, house);
    std::cout << "Enter Street: ";
    std::getline(std::cin, street);
    std::cout << "Enter City: ";
    std::getline(std::cin, city);
    std::cout << "Enter Country: ";
    std::getline(std::cin, country);
    Address obj(house, street, city, country);
    Contact contact(0, first_name, last_name, mobile_number, email_address, &obj);
    contactsBook.add_contact(contact);
    return in; // returning the adress of object
}
void Menu() // menu function to show menu
{
    std::cout << "\n\t\tMenu:\n";
    std::cout << "1 . Create a contacts list with given size\n";
    std::cout << "2 . Add New Contact\n";
    std::cout << "3 . Merge Duplicates\n";
    std::cout << "4 . Store To File\n";
    std::cout << "5 . Load From File\n";
    std::cout << "6 . Print Contacts Sorted\n";
    std::cout << "7 . Print Contacts\n";
    std::cout << "8 . Search contacts\n";
    std::cout << "9 . Display Count of Contacts\n";
    std::cout << "10. Create New Group\n";
    std::cout << "11. To Select a Contact and More Options\n";
    std::cout << "12. To Select a Group and More Options\n";
    std::cout << "13. To View Search History\n";
    std::cout << "0. Exit\n";
    std::cout << "Enter your choice: ";
}
int main() // main
{
    ContactsBook contactsBook(0); // Initialize with 0 size, will be set later
    int choice;
    int size;
    HistoryObjects history;
    std::string fileName;
    std::string first_name, last_name, mobile_number, email_address;
    std::string house, street, city, country;
    bool flag = true, temp = false;
    List<Group> groups;
    do // do while loop to show menu till user enters 0 to exit
    {
        Menu();
        std::string input;
        std::getline(std::cin, input);
        if (checkInput(input))
        {
            choice = stoi(input);
        }
        else
        {
            choice = 100;
        }
        switch (choice) // switch/case to run users entered choice
        {
        case 1:
        {
            std::cout << "Enter size of contacts list: ";
            if (!(std::cin >> size)) // error handling
            {
                std::cout << "Invalid input. Please enter a number.\n";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                continue;
            }
            contactsBook = ContactsBook(size);
            std::cout << "Contacts list created with size " << size << std::endl;
            break;
        }
        case 2:
        {
            std::cin >> contactsBook;
            break;
        }
        case 3:
        {
            contactsBook.merge_duplicates();
            std::cout << "Duplicates are merged\n";
            break;
        }
        case 4:
        {
            std::cout << "Enter file name to store contacts : ";
            std::cin >> fileName;
            contactsBook.save_to_file(fileName);
            std::cout << "Contacts stored to file '" << fileName << "'\n";
            break;
        }
        case 5:
        {
            std::cout << "Enter file name to load contacts : ";
            std::cin >> fileName;
            contactsBook.load_from_file(fileName);
            std::cout << "Contacts loaded from file '" << fileName << "'\n";
            break;
        }
        case 6:
        {
            std::string sortChoice;
            std::cout << "Enter sorting choice (first_name or last_name) : ";
            std::cin >> sortChoice;
            contactsBook.print_contacts_sorted(sortChoice);
            break;
        }
        case 7:
        {
            std::cout << "\n\t\t\tPrinting Contacts :\n\n";
            contactsBook.print_contacts();
            break;
        }
        case 8:
        {
            std::string searchString;
            std::cout << "Enter String for Search : ";
            getline(std::cin, searchString);
            List<Contact> Found = contactsBook.searchByString(searchString);
            std::cout << "\n\t\tMatched Contacts : " << std::endl;
            history.setHistory(searchString);
            break;
        }
        case 9:
        {
            std::cout << "Total Contacts: " << contactsBook.total_contacts() << std::endl;
            break;
        }
        case 10:
        {
            Group obj;
            std::string name;
            std::cout << "Enter Group Name : ";
            getline(std::cin, name);
            obj.setName(name);
            obj.setId(groups.size());
            groups.push(obj);
            // std::cout << "ID : " << groups[groups.size() - 1].getId() << std::endl;
            break;
        }
        case 11:
        {
            std::cout << "\n\t\t\tPrinting Contacts :\n\n";
            contactsBook.print_contacts();
            int id;
        std:
            std::cout << "Enter Id : ";
            std::cin >> id;
            std::cout << "Enter 1 : to Edit Contact   : \n";
            std::cout << "Enter 2 : to delete Contact : \n";
            int choice1;
            std::string input1;
            std::getline(std::cin, input1);
            if (checkInput(input1))
            {
                choice1 = stoi(input1);
            }
            else
            {
                choice1 = 100;
            }
            if (choice1 == 1)
            {
            }
            else if (choice == 2)
            {
            }
            break;
        }
        case 12:
        {
            for (int i = 0; i < groups.size(); i++)
            {
                std::cout << "Id : " << groups[i].getId() << std::endl;
                std::cout << "Group Name : " << groups[i].getname() << std::endl;
            }
            int choice1;
            std::string input1;
            std::getline(std::cin, input1);
            if (checkInput(input1))
            {
                choice1 = stoi(input1);
            }
            else
            {
                choice1 = 100;
            }
            if (choice1 == 1)
            {
            }
            else if (choice == 2)
            {
            }
            break;
        }
        case 13:
        {
            history.PrintHistory();
            break;
        }
        case 0:
        {
            std::cout << "Exiting program \n";
            flag = false;
            break;
        }
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
        system("pause");
    } while (flag);
    return 0;
}
