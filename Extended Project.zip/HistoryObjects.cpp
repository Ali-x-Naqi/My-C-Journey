#include "HistoryObjects.h"
void HistoryObjects::setHistory(std::string str)
{
    SearhHistory obj;
    std::string time = __TIME__;
    std::string date = __DATE__;
    std::string dateTime = time + "  " + date;
    obj.setDateTime(dateTime);
    obj.setSearchedString(str);
    array.push(obj);
}
void HistoryObjects::PrintHistory()
{
    for (int i = 0; i < array.size(); i++)
    {
        std::cout << "Date And Time : " << array[i].getDateTime() << std::endl;
        std::cout << "Searched String : " << array[i].getSearchedString() << std::endl;
    }
}
List<SearhHistory> HistoryObjects::getArray()
{
    return array;
}