#pragma once
#include <iostream>
#include <string>
class Address
{
private:
	std::string house;
	std::string street;
	std::string city;
	std::string country;

public:
	//Declaration of Functions 
	bool equals(const Address &address);
	Address()
	{
	}
	void print_address();
	Address copy_address();
	Address(const Address &obj);
	Address(std::string house, std::string street, std::string city, std::string country);
	void setHouse(std::string house);
	void setStreet(std::string street);
	void setCity(std::string city);
	void setCountry(std::string country);
	std::string getHouse();
	std::string getStreet();
	std::string getCity();
	std::string getCountry();
};
