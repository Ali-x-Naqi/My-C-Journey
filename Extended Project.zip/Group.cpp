// #include "Group.h"
// Group::Group()
// {
//     idMaker++;
//     id = idMaker;
// }
// void Group::setContactId(int contact_id)
// {
//     this->contact_id.push(contact_id);
// }
// void Group::deleteContact(int Id)
// {
//     for (int i = 0; i < contact_id.size(); i++)
//     {
//         if (id == contact_id[i])
//         {
//             contact_id.deleteIndex(i);
//         }
//     }
// }
// void Group::setName(std::string name)
// {
//     this->name = name;
// }
// std::string Group::getname()
// {
//     return name;
// }
// int Group::getSize()
// {
//     return contact_id.size();
// }
// int Group::getId()
// {
//     return id;
// }
// int Group::idMaker = 0;