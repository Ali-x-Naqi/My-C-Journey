#pragma once
#include "SearchHistory.h"
#include "List.h"
class HistoryObjects
{
private:
    List<SearhHistory> array;

public:
    HistoryObjects() {}
    void setHistory(std::string str);
    List<SearhHistory> getArray();
    void PrintHistory();
};