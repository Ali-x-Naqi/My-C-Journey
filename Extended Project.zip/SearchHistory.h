#pragma once
#include <string>
class SearhHistory
{
private:
    std::string dateTime;
    std::string SearchedString;

public:
    SearhHistory() {}
    void setDateTime(std::string dateTime);
    void setSearchedString(std::string searchedString);
    std::string getDateTime();
    std::string getSearchedString();
};